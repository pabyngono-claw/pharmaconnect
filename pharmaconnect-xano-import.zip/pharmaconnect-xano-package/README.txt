PharmaConnect v2.0 — Xano Import Package
==========================================

Files:
- pharmaconnect-full-import.sql : single consolidated file (schema + seed)
- 01-enums.sql, 02-tables.sql, 03-indexes.sql, 04-triggers.sql : schema blocks
- 01-organization.sql .. 05-subscriptions.sql : seed data blocks
- schema.sql : original full schema

Import order:
1. Run 01-enums.sql through 04-triggers.sql in Xano Console Database > Query
2. Run seed files in order: 01-organization.sql, 02-users.sql, 03-documents.sql, 04-active-flow.sql, 05-subscriptions.sql
   OR run pharmaconnect-full-import.sql once.

After import:
- Verify 21 tables exist
- Verify seed data loaded
- Proceed to API Groups setup per backend/xano/api-groups-setup.md
