PharmaConnect v2.0 — Xano Native Build Package
=================================================

Build the backend manually in Xano console using these docs.

Contents:
- xano-native-schema.md : exact table/field/relation specs for Xano Database
- xano-api-spec.md : API Groups, routes, and function logic
- xano-manual-build.md : step-by-step build checklist
- xano-scheduled-jobs-import.md : scheduler job config
- xano-seed-guide.md : how to load demo data
- quick-apply-routes.md : route registry shortcut
- function-patterns.md : copy-pasteable function patterns
- *.csv : seed data for import

Order:
1. Build tables per xano-native-schema.md
2. Build API Groups per xano-api-spec.md
3. Load seed data using CSVs
4. Configure scheduled jobs
5. Set environment variables
